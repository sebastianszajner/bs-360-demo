<?php
/*
 * Backend badania 360 dla brainstream.pl. Jeden plik, bez zaleznosci.
 * Dane trzyma w data/db.json (katalog data ma .htaccess deny, wiec nie jest dostepny z sieci).
 * Respondent moze tylko zapisac swoja ankiete. Odczyt wynikow i zarzadzanie wymaga klucza admina.
 */

const ADMIN_KEY = 'qvvtgPc8ubygUq8Dt-12WpYD';

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

$DATA_DIR = __DIR__ . '/data';
$DB = $DATA_DIR . '/db.json';
$RECS = $DATA_DIR . '/recommendations.json';

function ensure_storage($dir) {
  if (!is_dir($dir)) { @mkdir($dir, 0755, true); }
  $ht = $dir . '/.htaccess';
  if (!file_exists($ht)) {
    @file_put_contents($ht, "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n");
  }
  // katalog drugiej kopii (backup per wypelnienie). .htaccess z katalogu data chroni tez podkatalogi.
  $bk = $dir . '/backups';
  if (!is_dir($bk)) { @mkdir($bk, 0755, true); }
}

// usuwa katalog rekurencyjnie (sprzatanie backupow kampanii, RODO)
function rrmdir($path) {
  if (!is_dir($path)) return;
  $items = @scandir($path);
  if ($items === false) return;
  foreach ($items as $it) {
    if ($it === '.' || $it === '..') continue;
    $p = $path . '/' . $it;
    if (is_dir($p)) rrmdir($p); else @unlink($p);
  }
  @rmdir($path);
}

// czysta nazwa katalogu z id kampanii (tylko bezpieczne znaki)
function safe_seg($s) { return preg_replace('/[^A-Za-z0-9_]/', '', (string)$s); }

function fail($code, $msg) {
  http_response_code($code);
  echo json_encode(['error' => $msg]);
  exit;
}

function read_db($db) {
  if (!file_exists($db)) return ['campaigns' => [], 'invites' => [], 'submissions' => []];
  $raw = file_get_contents($db);
  $j = json_decode($raw, true);
  if (!is_array($j)) return ['campaigns' => [], 'invites' => [], 'submissions' => []];
  $j += ['campaigns' => [], 'invites' => [], 'submissions' => []];
  return $j;
}

function write_db($db, $data) {
  $fp = fopen($db, 'c+');
  if (!$fp) return false;
  flock($fp, LOCK_EX);
  ftruncate($fp, 0);
  rewind($fp);
  fwrite($fp, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
  fflush($fp);
  flock($fp, LOCK_UN);
  fclose($fp);
  return true;
}

function token($len = 10) {
  $a = 'abcdefghijkmnpqrstuvwxyz23456789';
  $s = '';
  for ($i = 0; $i < $len; $i++) $s .= $a[random_int(0, strlen($a) - 1)];
  return $s;
}

function is_admin() {
  $h = isset($_SERVER['HTTP_X_ADMIN_KEY']) ? $_SERVER['HTTP_X_ADMIN_KEY'] : '';
  return is_string($h) && hash_equals(ADMIN_KEY, $h);
}

function require_admin() {
  if (!is_admin()) fail(401, 'Brak uprawnien administratora.');
}

function scored($answers) {
  $vals = [];
  foreach ($answers as $v) { if (is_numeric($v) && $v >= 0) $vals[] = $v + 0; }
  $answered = count($vals);
  $avg = $answered ? round(array_sum($vals) / $answered, 2) : 0;
  return [$answered, $avg];
}

ensure_storage($DATA_DIR);

$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? $_GET['action'] : '';
$body = [];
if ($method === 'POST') {
  $raw = file_get_contents('php://input');
  $body = json_decode($raw, true);
  if (!is_array($body)) $body = [];
  if (!$action && isset($body['action'])) $action = $body['action'];
}

$db = read_db($DB);

switch ($action) {

  case 'pdf': {
    // Serwerowy render PDF raportu. Klient przysyła gotowe wartości (JSON), my składamy stronę.
    // Publiczne: dane są zagregowane i bezpieczne (jak link do raportu). Bez html2canvas.
    if (!is_array($body) || empty($body)) { http_response_code(400); echo json_encode(['error' => 'no data']); break; }
    require __DIR__ . '/pdf_render.php';
    render_report_pdf($body);
    exit;
  }

  case 'listCampaigns':
    require_admin();
    echo json_encode($db['campaigns']);
    break;

  case 'getCampaign': {
    $id = isset($_GET['id']) ? $_GET['id'] : '';
    foreach ($db['campaigns'] as $c) {
      if ($c['id'] === $id) { echo json_encode(['id' => $c['id'], 'managerName' => $c['managerName'], 'managerPosition' => $c['managerPosition'], 'createdAt' => $c['createdAt']]); exit; }
    }
    echo json_encode(null);
    break;
  }

  case 'createCampaign': {
    require_admin();
    $name = trim(isset($body['managerName']) ? $body['managerName'] : '');
    $pos = trim(isset($body['managerPosition']) ? $body['managerPosition'] : '');
    if ($name === '') fail(400, 'Brak nazwiska ocenianej osoby.');
    $c = ['id' => 'camp_' . token(12), 'managerName' => $name, 'managerPosition' => $pos !== '' ? $pos : 'Menedzer', 'createdAt' => gmdate('c')];
    array_unshift($db['campaigns'], $c);
    write_db($DB, $db);
    echo json_encode($c);
    break;
  }

  // EDYCJA DANYCH OCENIANEGO. Zmienia imie/nazwisko i stanowisko, zachowuje id kampanii,
  // tokeny zaproszen i submisje (linki dzialaja dalej). Token/dane respondentow nietkniete.
  case 'updateCampaign': {
    require_admin();
    $id = isset($body['id']) ? $body['id'] : '';
    $found = null;
    foreach ($db['campaigns'] as $k => $c) {
      if ($c['id'] === $id) {
        if (isset($body['managerName'])) { $nm = trim($body['managerName']); if ($nm !== '') $db['campaigns'][$k]['managerName'] = $nm; }
        if (isset($body['managerPosition'])) { $db['campaigns'][$k]['managerPosition'] = trim($body['managerPosition']); }
        $found = $db['campaigns'][$k];
        break;
      }
    }
    if ($found === null) fail(404, 'Nie znaleziono kampanii.');
    write_db($DB, $db);
    echo json_encode($found);
    break;
  }

  case 'deleteCampaign': {
    require_admin();
    $id = isset($body['id']) ? $body['id'] : '';
    $db['campaigns'] = array_values(array_filter($db['campaigns'], fn($c) => $c['id'] !== $id));
    $db['invites'] = array_values(array_filter($db['invites'], fn($i) => $i['campaignId'] !== $id));
    $db['submissions'] = array_values(array_filter($db['submissions'], fn($s) => $s['campaignId'] !== $id));
    write_db($DB, $db);
    // RODO: usun tez druga kopie (backupy) tej kampanii
    rrmdir($DATA_DIR . '/backups/' . safe_seg($id));
    echo json_encode(['ok' => true]);
    break;
  }

  case 'addInvite': {
    require_admin();
    $cid = isset($body['campaignId']) ? $body['campaignId'] : '';
    $role = isset($body['role']) ? $body['role'] : '';
    $label = trim(isset($body['label']) ? $body['label'] : '');
    if (!in_array($role, ['sam', 'prz', 'wsp', 'pod'], true)) fail(400, 'Zla rola.');
    $inv = ['token' => token(), 'campaignId' => $cid, 'role' => $role, 'label' => $label, 'status' => 'pending', 'createdAt' => gmdate('c')];
    $db['invites'][] = $inv;
    write_db($DB, $db);
    echo json_encode($inv);
    break;
  }

  case 'removeInvite': {
    require_admin();
    $cid = isset($body['campaignId']) ? $body['campaignId'] : '';
    $tok = isset($body['token']) ? $body['token'] : '';
    $db['invites'] = array_values(array_filter($db['invites'], fn($i) => !($i['campaignId'] === $cid && $i['token'] === $tok)));
    write_db($DB, $db);
    echo json_encode(['ok' => true]);
    break;
  }

  // CZYSZCZENIE WYPELNIENIA. Usuwa submisje danego linku (kopia glowna + kopia zapasowa)
  // i cofa zaproszenie do statusu pending, zeby link byl znow czysty do wyslania. Token wymagany.
  case 'resetInvite': {
    require_admin();
    $cid = isset($body['campaignId']) ? $body['campaignId'] : '';
    $tok = isset($body['token']) ? $body['token'] : '';
    if ($cid === '' || $tok === '') fail(400, 'Brak campaignId lub token.');
    $removed = 0; $kept = [];
    foreach ($db['submissions'] as $s) {
      if ($s['campaignId'] === $cid && isset($s['token']) && $s['token'] === $tok) {
        $bf = $DATA_DIR . '/backups/' . safe_seg($cid) . '/' . safe_seg($s['id']) . '.json';
        if (is_file($bf)) @unlink($bf);
        $removed++;
      } else { $kept[] = $s; }
    }
    $db['submissions'] = $kept;
    foreach ($db['invites'] as $k => $i) {
      if ($i['campaignId'] === $cid && $i['token'] === $tok) {
        $db['invites'][$k]['status'] = 'pending';
        unset($db['invites'][$k]['completedAt']);
        unset($db['invites'][$k]['backupFile']);
      }
    }
    write_db($DB, $db);
    echo json_encode(['ok' => true, 'removed' => $removed]);
    break;
  }

  case 'listInvites': {
    require_admin();
    $cid = isset($_GET['campaignId']) ? $_GET['campaignId'] : '';
    echo json_encode(array_values(array_filter($db['invites'], fn($i) => $i['campaignId'] === $cid)));
    break;
  }

  case 'getInvite': {
    $cid = isset($_GET['campaignId']) ? $_GET['campaignId'] : '';
    $tok = isset($_GET['token']) ? $_GET['token'] : '';
    foreach ($db['invites'] as $i) {
      if ($i['campaignId'] === $cid && $i['token'] === $tok) { echo json_encode($i); exit; }
    }
    echo json_encode(null);
    break;
  }

  case 'submit': {
    $cid = isset($body['campaignId']) ? $body['campaignId'] : '';
    $tok = isset($body['token']) ? $body['token'] : '';
    $role = isset($body['role']) ? $body['role'] : '';
    $name = trim(isset($body['respondentName']) ? $body['respondentName'] : '');
    $answers = isset($body['answers']) && is_array($body['answers']) ? $body['answers'] : null;
    if ($answers === null) fail(400, 'Brak odpowiedzi.');
    // walidacja: zaproszenie musi istniec i nie byc wypelnione. Indeks zapamietujemy,
    // ale status 'done' ustawiamy DOPIERO po potwierdzeniu obu kopii (patrz nizej).
    $idx = -1;
    foreach ($db['invites'] as $k => $i) {
      if ($i['campaignId'] === $cid && $i['token'] === $tok) {
        $idx = $k;
        if ($i['status'] === 'done') fail(409, 'Ta ankieta zostala juz wypelniona.');
        if ($role === '') $role = $i['role'];
        break;
      }
    }
    if ($idx < 0) fail(404, 'Nieprawidlowy link ankiety.');
    list($answered, $avg) = scored($answers);
    // pytania otwarte (id pytania => tekst). Sanityzacja: tylko stringi, przyciete, limit dlugosci.
    $openAnswers = array();
    if (isset($body['openAnswers']) && is_array($body['openAnswers'])) {
      foreach ($body['openAnswers'] as $qid => $txt) {
        if (!is_string($txt)) continue;
        $txt = trim($txt);
        if ($txt === '') continue;
        $openAnswers[(string)$qid] = mb_substr($txt, 0, 2000);
      }
    }
    $id = 'sub_' . token(12);
    $rec = ['id' => $id, 'campaignId' => $cid, 'token' => $tok, 'role' => $role, 'respondentName' => $name !== '' ? $name : 'Anonim', 'answers' => $answers, 'openAnswers' => $openAnswers, 'answered' => $answered, 'avg' => $avg, 'ts' => gmdate('c')];

    // ===== PODWOJNY ZAPIS =====
    // KOPIA 2 (zapasowa, niezalezny plik per wypelnienie) — najpierw, bo jest nieodwracalna i izolowana.
    $seg = safe_seg($cid);
    $bdir = $DATA_DIR . '/backups/' . $seg;
    if (!is_dir($bdir)) @mkdir($bdir, 0755, true);
    $bfile = $bdir . '/' . $id . '.json';
    $bwrote = @file_put_contents($bfile, json_encode($rec, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
    // weryfikacja kopii zapasowej: odczyt z powrotem i porownanie id
    $bok = false;
    if ($bwrote !== false && is_file($bfile)) {
      $chk = json_decode(@file_get_contents($bfile), true);
      $bok = is_array($chk) && isset($chk['id']) && $chk['id'] === $id;
    }
    if (!$bok) fail(500, 'Backup zapasowy nie powiodl sie. Twoje odpowiedzi nie zostaly zapisane. Sprobuj ponownie.');

    // KOPIA 1 (glowna, db.json) + oznaczenie zaproszenia jako wypelnione w tym samym zapisie.
    $db['invites'][$idx]['status'] = 'done';
    $db['invites'][$idx]['completedAt'] = gmdate('c');
    $db['invites'][$idx]['backupFile'] = 'backups/' . $seg . '/' . $id . '.json';
    array_unshift($db['submissions'], $rec);
    $pwrote = write_db($DB, $db);
    // weryfikacja kopii glownej: ponowny odczyt i odnalezienie id
    $pok = false;
    if ($pwrote) {
      $re = read_db($DB);
      foreach ($re['submissions'] as $s) { if (isset($s['id']) && $s['id'] === $id) { $pok = true; break; } }
    }
    if (!$pok) fail(500, 'Zapis glowny nie powiodl sie. Kopia zapasowa istnieje, ale zapis nie jest podwojny. Sprobuj ponownie.');

    // Sukces tylko, gdy OBIE kopie potwierdzone odczytem.
    $rec['backup'] = ['primary' => true, 'secondary' => true, 'verified' => true, 'file' => 'backups/' . $seg . '/' . $id . '.json', 'at' => gmdate('c')];
    echo json_encode($rec);
    break;
  }

  case 'listSubmissions': {
    require_admin();
    $cid = isset($_GET['campaignId']) ? $_GET['campaignId'] : '';
    echo json_encode(array_values(array_filter($db['submissions'], fn($s) => $s['campaignId'] === $cid)));
    break;
  }

  // WERYFIKACJA PODWOJNEGO ZAPISU. Sprawdza, czy dane wypelnienie jest w OBU kopiach:
  // glownej (db.json) i zapasowej (plik backups/<cid>/<id>.json). Diagnostyka i test.
  case 'verifySubmission': {
    require_admin();
    $cid = isset($_GET['campaignId']) ? $_GET['campaignId'] : (isset($body['campaignId']) ? $body['campaignId'] : '');
    $sid = isset($_GET['id']) ? $_GET['id'] : (isset($body['id']) ? $body['id'] : '');
    $inPrimary = false;
    foreach ($db['submissions'] as $s) { if (isset($s['id']) && $s['id'] === $sid) { $inPrimary = true; break; } }
    $bfile = $DATA_DIR . '/backups/' . safe_seg($cid) . '/' . safe_seg($sid) . '.json';
    $inBackup = false;
    if (is_file($bfile)) {
      $chk = json_decode(@file_get_contents($bfile), true);
      $inBackup = is_array($chk) && isset($chk['id']) && $chk['id'] === $sid;
    }
    echo json_encode(['id' => $sid, 'inPrimary' => $inPrimary, 'inBackup' => $inBackup, 'ok' => ($inPrimary && $inBackup)]);
    break;
  }

  // RAPORT ZBIORCZY do udostępnienia (np. ocenianemu menedżerowi). Zwraca TYLKO agregaty
  // per rola (bez nazwisk, bez pojedynczych wierszy), więc można dać link bez klucza admina.
  case 'getReport': {
    $cid = isset($_GET['campaignId']) ? $_GET['campaignId'] : '';
    $camp = null;
    foreach ($db['campaigns'] as $c) { if ($c['id'] === $cid) { $camp = $c; break; } }
    if (!$camp) { echo json_encode(null); break; }
    $counts = ['sam' => 0, 'prz' => 0, 'wsp' => 0, 'pod' => 0];
    $ans = [];
    $open = []; // pytania otwarte pogrupowane wg roli (kategorii ankiety), bez nazwisk
    foreach ($db['submissions'] as $s) {
      if ($s['campaignId'] !== $cid) continue;
      $role = $s['role'];
      $counts[$role] = ($counts[$role] ?? 0) + 1;
      foreach ($s['answers'] as $bid => $v) {
        if (!isset($ans[$bid])) $ans[$bid] = ['sam' => [], 'prz' => [], 'wsp' => [], 'pod' => []];
        $ans[$bid][$role][] = $v;
      }
      if (isset($s['openAnswers']) && is_array($s['openAnswers'])) {
        foreach ($s['openAnswers'] as $qid => $txt) {
          if (!is_string($txt) || trim($txt) === '') continue;
          if (!isset($open[$role])) $open[$role] = [];
          if (!isset($open[$role][$qid])) $open[$role][$qid] = [];
          $open[$role][$qid][] = trim($txt);
        }
      }
    }
    echo json_encode(['managerName' => $camp['managerName'], 'managerPosition' => $camp['managerPosition'], 'counts' => $counts, 'answers' => empty($ans) ? new stdClass() : $ans, 'open' => empty($open) ? new stdClass() : $open]);
    break;
  }

  // ZAMROŻONE REKOMENDACJE — nadpisania kuratorskie. Odczyt publiczny (to szablony, nie dane osobowe),
  // zapis tylko admin. Format: { "K2:ponizej": [ {title, action, horizon}, ... ], ... }
  case 'getRecommendations': {
    if (!file_exists($RECS)) { echo json_encode(new stdClass()); break; }
    $raw = file_get_contents($RECS);
    $j = json_decode($raw, true);
    echo json_encode(is_array($j) ? $j : new stdClass());
    break;
  }

  case 'saveRecommendations': {
    require_admin();
    $data = isset($body['recommendations']) && is_array($body['recommendations']) ? $body['recommendations'] : null;
    if ($data === null) fail(400, 'Brak danych rekomendacji.');
    $fp = fopen($RECS, 'c+');
    if (!$fp) fail(500, 'Nie udalo sie zapisac.');
    flock($fp, LOCK_EX); ftruncate($fp, 0); rewind($fp);
    fwrite($fp, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    fflush($fp); flock($fp, LOCK_UN); fclose($fp);
    echo json_encode(['ok' => true]);
    break;
  }

  case 'ping':
    echo json_encode(['ok' => true, 'admin' => is_admin()]);
    break;

  default:
    fail(400, 'Nieznana akcja.');
}
