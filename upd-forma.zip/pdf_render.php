<?php
/*
 * Serwerowy render PDF raportu 360 (brainstream). tFPDF (UTF-8, polskie znaki).
 * Klient liczy wszystko po swojej stronie i wysyła gotowe wartości w JSON.
 * Tu tylko układamy stronę. Bez html2canvas, bez zatruwania canvas, kompletny PDF.
 */

function render_report_pdf($d) {
  require_once __DIR__ . '/tfpdf/tfpdf.php';
  // tFPDF 1.33 ma zakomentowany require parsera TTF (liczy na autoload composera).
  // Bez composera musimy załadować go ręcznie, inaczej AddFont rzuca "TTFontFile not found".
  require_once __DIR__ . '/tfpdf/font/unifont/ttfonts.php';

  // Podklasa z brandową stopką (numer strony + podpis SUUS na każdej stronie poza okładką).
  if (!class_exists('BSPdf')) {
    class BSPdf extends tFPDF {
      public $footL = '';
      function Footer() {
        if ($this->PageNo() <= 1) return; // okładka bez stopki
        $this->SetY(-11);
        $this->SetDrawColor(224, 230, 238); $this->SetLineWidth(0.2);
        $this->Line(15, $this->GetY(), 195, $this->GetY());
        $this->SetY(-9.2);
        $this->SetFont('dv', '', 7.5); $this->SetTextColor(150, 163, 184);
        $this->Cell(120, 5, $this->footL, 0, 0, 'L');
        $this->Cell(60, 5, 'strona ' . $this->PageNo(), 0, 0, 'R');
      }
    }
  }

  $NAVY = array(11, 31, 58);
  $INK = array(31, 41, 55);
  $MUTE = array(107, 114, 128);
  $LINE = array(229, 231, 235);
  $BG = array(248, 250, 252);

  $S = function ($v, $def = '') { return isset($v) && $v !== null ? (string)$v : $def; };

  $pdf = new BSPdf('P', 'mm', 'A4');
  $pdf->SetAutoPageBreak(true, 18);
  $pdf->SetMargins(15, 15, 15);
  $pdf->AddFont('dv', '', 'DejaVuSansCondensed.ttf', true);
  $pdf->AddFont('dv', 'B', 'DejaVuSansCondensed-Bold.ttf', true);
  $pdf->footL = 'Raport rozwojowy 360°   ·   Röhlig SUUS Logistics';
  $pdf->AddPage();   // pierwsza strona (okładka) — bez tego FPDF rzuca "No page has been added"

  $W = 210; $CW = 180; $LX = 15; $RX = 195;

  $setFill = function ($c) use ($pdf) { $pdf->SetFillColor($c[0], $c[1], $c[2]); };
  $setText = function ($c) use ($pdf) { $pdf->SetTextColor($c[0], $c[1], $c[2]); };
  $setDraw = function ($c) use ($pdf) { $pdf->SetDrawColor($c[0], $c[1], $c[2]); };
  $CW = 180; $LX = 15;

  $h2 = function ($t) use ($pdf, $NAVY, $setText, $setFill, $LX) {
    $pdf->Ln(3); $y = $pdf->GetY();
    $setFill(array(0, 172, 234)); $pdf->Rect($LX, $y + 0.5, 14, 1.6, 'F'); // akcent brandowy SUUS
    $pdf->SetY($y + 4);
    $pdf->SetFont('dv', 'B', 13); $setText($NAVY); $pdf->Cell(0, 8, $t, 0, 1); $pdf->Ln(0.5);
  };
  $para = function ($t) use ($pdf, $INK, $setText, $CW) {
    if ($t === '' || $t === null) return;
    $pdf->SetFont('dv', '', 10); $setText($INK); $pdf->MultiCell($CW, 5.2, $t, 0, 'L'); $pdf->Ln(1.5);
  };
  $pairList = function ($items, $accent) use ($pdf, $setText, $CW) {
    foreach ($items as $it) {
      if ($pdf->GetY() > 255) $pdf->AddPage();
      $pdf->SetFont('dv', 'B', 10); $setText($accent); $pdf->MultiCell($CW, 5, isset($it[0]) ? $it[0] : '', 0, 'L');
      $pdf->SetFont('dv', '', 9.5); $setText(array(75, 85, 99)); $pdf->MultiCell($CW, 4.8, isset($it[1]) ? $it[1] : '', 0, 'L');
      $pdf->Ln(2.5);
    }
  };

  // ---------- LINKI WEWNĘTRZNE (klikalny spis treści) ----------
  // AddLink rezerwuje id; SetLink (przy renderze sekcji) wiąże go z konkretną stroną/pozycją.
  $toc = array();
  $addToc = function ($label, $indent = false) use ($pdf, &$toc) { $lk = $pdf->AddLink(); $toc[] = array($label, $lk, $indent); return $lk; };
  $Lk = !empty($d['kluczowyWniosek']) ? $addToc('Kluczowy wniosek') : null;
  $La = (!empty($d['analiza']) && is_array($d['analiza'])) ? $addToc('Analiza globalna') : null;
  $Lh = (!empty($d['heatmap']['rows']) && is_array($d['heatmap']['rows'])) ? $addToc('Mapa cieplna') : null;
  $Lg = (!empty($d['gaps']['items']) && is_array($d['gaps']['items'])) ? $addToc('Luki percepcji') : null;
  $Lpe = (!empty($d['perspectives']['items']) && is_array($d['perspectives']['items'])) ? $addToc('Perspektywy: kto jak ocenia') : null;
  $compLinks = array();
  if (!empty($d['competencies']) && is_array($d['competencies'])) {
    foreach ($d['competencies'] as $ci => $cc) { $compLinks[$ci] = $addToc($S(@$cc['name'], 'Wartość ' . ($ci + 1))); }
  }
  $Lp = (!empty($d['plan']) && is_array($d['plan'])) ? $addToc('Plan rozwoju') : null;
  $Lo = (!empty($d['openAnswers']) && is_array($d['openAnswers'])) ? $addToc('Pytania otwarte') : null;

  // ---------- OKŁADKA ----------
  $coverH = 64;
  $setFill($NAVY); $pdf->Rect(0, 0, $W, $coverH, 'F');
  // pasek akcentu w kolorach 4 wartości SUUS na dole granatu
  $accent = array(array(0, 134, 207), array(148, 193, 30), array(0, 172, 234), array(23, 65, 151));
  $aw = $W / count($accent);
  foreach ($accent as $i => $ac) { $setFill($ac); $pdf->Rect($i * $aw, $coverH - 1.8, $aw, 1.8, 'F'); }
  // logo SUUS w białym polu (prawy górny róg)
  $logo = __DIR__ . '/suus/suus-logo.png';
  if (is_file($logo)) {
    $setFill(array(255, 255, 255)); $pdf->Rect($RX - 46, 12.5, 46, 13, 'F');
    $pdf->Image($logo, $RX - 42, 15, 0, 8);
  }
  $pdf->SetFont('dv', '', 9); $setText(array(150, 165, 188));
  $pdf->SetXY($LX, 17); $pdf->Cell(0, 5, $S(@$d['kicker'], 'BADANIE 360 STOPNI'), 0, 1);
  $pdf->SetFont('dv', 'B', 25); $setText(array(255, 255, 255));
  $pdf->SetXY($LX, 24); $pdf->Cell(0, 12, $S(@$d['title'], 'Raport 360'), 0, 1);
  $pdf->SetFont('dv', 'B', 15); $setText(array(255, 255, 255));
  $pdf->SetXY($LX, 41); $pdf->Cell(0, 8, $S(@$d['manager']), 0, 1);
  $pdf->SetFont('dv', '', 10); $setText(array(190, 203, 222));
  $pdf->SetXY($LX, 50); $pdf->Cell(0, 6, trim($S(@$d['position']) . '   ·   ' . $S(@$d['meta']), ' ·'), 0, 1);

  $pdf->SetY($coverH + 8);

  // ---------- KARTY WARTOŚCI (mini-dashboard na start) ----------
  if (!empty($d['competencies']) && is_array($d['competencies'])) {
    $cs = $d['competencies']; $n = max(1, count($cs));
    $gap = 4; $cardW = ($CW - $gap * ($n - 1)) / $n; $cardH = 22; $y = $pdf->GetY();
    foreach ($cs as $i => $c) {
      $x = $LX + $i * ($cardW + $gap);
      $rgb = (isset($c['rgb']) && is_array($c['rgb'])) ? $c['rgb'] : $NAVY;
      $setFill(array(248, 250, 252)); $pdf->Rect($x, $y, $cardW, $cardH, 'F');
      $setFill($rgb); $pdf->Rect($x, $y, $cardW, 2.2, 'F');
      $pdf->SetFont('dv', '', 7.5); $setText($MUTE);
      $pdf->SetXY($x, $y + 4.6); $pdf->Cell($cardW, 4, mb_strtoupper($S(@$c['name']), 'UTF-8'), 0, 0, 'C');
      $pdf->SetFont('dv', 'B', 17); $setText($NAVY);
      $pdf->SetXY($x, $y + 9); $pdf->Cell($cardW, 9, $S(@$c['score']), 0, 0, 'C');
    }
    $pdf->SetY($y + $cardH + 7);
  }

  // ---------- WSKAŹNIK GLOBALNY (pasek postępu) ----------
  if (isset($d['globalPct'])) {
    $pct = (int)$d['globalPct']; $y = $pdf->GetY();
    $pdf->SetFont('dv', 'B', 10); $setText($NAVY);
    $pdf->SetXY($LX, $y); $pdf->Cell($CW - 18, 5, $S(@$d['globalLabel'], 'Dopasowanie do standardu SUUS'), 0, 0);
    $pdf->SetFont('dv', 'B', 13); $setText($NAVY); $pdf->Cell(18, 5, $pct . '%', 0, 1, 'R');
    $by = $pdf->GetY() + 1.5;
    $setFill(array(233, 237, 242)); $pdf->Rect($LX, $by, $CW, 4, 'F');
    $setFill($NAVY); $pdf->Rect($LX, $by, $CW * $pct / 100, 4, 'F');
    $pdf->SetY($by + 9);
  }

  // ---------- WSTĘP ----------
  if (!empty($d['intro']) && is_array($d['intro'])) {
    $pdf->SetFont('dv', '', 10); $setText($INK);
    foreach ($d['intro'] as $p) { $pdf->MultiCell($CW, 5.2, $S($p), 0, 'L'); $pdf->Ln(2); }
  }

  // ---------- KLUCZOWY WNIOSEK ----------
  if (!empty($d['kluczowyWniosek'])) {
    if ($pdf->GetY() > 210) $pdf->AddPage();
    $y = $pdf->GetY() + 2;
    $setFill(array(240, 245, 252)); $pdf->Rect($LX, $y, $CW, 1.5, 'F');
    $pdf->SetY($y + 4);
    if ($Lk !== null) $pdf->SetLink($Lk, -1);
    $h2('Kluczowy wniosek');
    $para($S($d['kluczowyWniosek']));
  }

  // ---------- SPIS TREŚCI (klikalny) ----------
  if (count($toc) > 1) {
    $pdf->AddPage();
    $h2('Spis treści');
    $para('Kliknij pozycję, aby przejść prosto do niej w raporcie.');
    $pdf->Ln(1);
    $n = 0;
    foreach ($toc as $t) {
      $label = $t[0]; $lk = $t[1]; $indent = !empty($t[2]);
      if ($pdf->GetY() > 270) $pdf->AddPage();
      if ($indent) {
        $pdf->SetFont('dv', '', 10); $setText(array(75, 85, 99));
        $pdf->Cell(12, 6, '', 0, 0);
        $pdf->Cell(0, 6, $label, 0, 1, 'L', false, $lk);
      } else {
        $n++;
        $pdf->SetFont('dv', 'B', 11); $setText($NAVY);
        $pdf->Cell(8, 7, $n . '.', 0, 0, 'L', false, $lk);
        $pdf->Cell(0, 7, $label, 0, 1, 'L', false, $lk);
      }
    }
  }

  // ---------- ANALIZA GLOBALNA ----------
  if (!empty($d['analiza']) && is_array($d['analiza'])) {
    $a = $d['analiza'];
    $pdf->AddPage(); if ($La !== null) $pdf->SetLink($La, -1); $h2('Analiza globalna');
    if (!empty($a['wprowadzenie'])) foreach ($a['wprowadzenie'] as $p) $para($S($p));
    if (!empty($a['wnioski'])) {
      $pdf->SetFont('dv', 'B', 10); $setText($NAVY); $pdf->Cell(0, 6, 'Główne wnioski', 0, 1); $pdf->Ln(0.5);
      foreach ($a['wnioski'] as $p) $para($S($p));
    }
    if (!empty($a['mocne'])) {
      if ($pdf->GetY() > 245) $pdf->AddPage();
      $pdf->SetFont('dv', 'B', 11); $setText(array(34, 139, 74)); $pdf->Cell(0, 7, 'Mocne strony', 0, 1);
      $pairList($a['mocne'], array(34, 139, 74));
    }
    if (!empty($a['obszary'])) {
      if ($pdf->GetY() > 245) $pdf->AddPage();
      $pdf->SetFont('dv', 'B', 11); $setText(array(234, 88, 12)); $pdf->Cell(0, 7, 'Obszary do rozwoju', 0, 1);
      $pairList($a['obszary'], array(234, 88, 12));
    }
    if (!empty($a['synteza'])) { $pdf->Ln(1); foreach ($a['synteza'] as $p) $para($S($p)); }
  }

  // ---------- MAPA CIEPLNA ----------
  if (!empty($d['heatmap']['rows']) && is_array($d['heatmap']['rows'])) {
    $pdf->AddPage(); if ($Lh !== null) $pdf->SetLink($Lh, -1); $h2('Mapa cieplna: wartości i grupy oceniające');
    $para('Im ciemniejsza komórka, tym wyższa ocena. Widać, gdzie zespół jest jednomyślny.');
    $roles = $d['heatmap']['roles']; $nr = max(1, count($roles));
    $labelW = 42; $colW = ($CW - $labelW) / $nr;
    $pdf->SetFont('dv', '', 8); $setText($MUTE); $pdf->SetX($LX + $labelW);
    foreach ($roles as $r) { $pdf->Cell($colW, 6, $S($r), 0, 0, 'C'); }
    $pdf->Ln(7);
    foreach ($d['heatmap']['rows'] as $row) {
      if ($pdf->GetY() > 250) $pdf->AddPage();
      $y = $pdf->GetY();
      $pdf->SetFont('dv', '', 9); $setText($INK); $pdf->SetXY($LX, $y + 1); $pdf->Cell($labelW, 7, $S(@$row['name']), 0, 0);
      $x = $LX + $labelW;
      foreach ($row['cells'] as $cell) {
        $rgb = (isset($cell['rgb']) && is_array($cell['rgb'])) ? $cell['rgb'] : array(229, 231, 235);
        $setFill($rgb); $pdf->Rect($x + 1, $y, $colW - 2, 9, 'F');
        $lum = 0.299 * $rgb[0] + 0.587 * $rgb[1] + 0.114 * $rgb[2];
        $setText($lum < 140 ? array(255, 255, 255) : $NAVY);
        $pdf->SetFont('dv', 'B', 9); $pdf->SetXY($x + 1, $y + 2); $pdf->Cell($colW - 2, 5, $S(@$cell['v']), 0, 0, 'C');
        $x += $colW;
      }
      $pdf->SetY($y + 11);
    }
  }

  // ---------- LUKI PERCEPCJI ----------
  if (!empty($d['gaps']['items']) && is_array($d['gaps']['items'])) {
    if ($pdf->GetY() > 220) $pdf->AddPage(); else $pdf->Ln(4);
    if ($Lg !== null) $pdf->SetLink($Lg, -1);
    $h2('Luki percepcji: samoocena na tle otoczenia');
    $gmax = isset($d['gaps']['max']) ? (float)$d['gaps']['max'] : 4.0;
    foreach ($d['gaps']['items'] as $g) {
      if ($pdf->GetY() > 255) $pdf->AddPage();
      $gv = isset($g['gap']) ? (float)$g['gap'] : 0;
      $pdf->SetFont('dv', 'B', 9); $setText($NAVY); $pdf->Cell(130, 6, $S(@$g['name']), 0, 0);
      $setText($gv > 0.1 ? array(234, 88, 12) : ($gv < -0.1 ? array(37, 99, 235) : $MUTE));
      $pdf->Cell($CW - 130, 6, ($gv > 0 ? '+' : '') . number_format($gv, 1), 0, 1, 'R');
      $y = $pdf->GetY() + 1;
      $setFill(array(235, 238, 242)); $pdf->Rect($LX, $y, $CW, 1.2, 'F');
      $others = (float)@$g['others']; $self = (float)@$g['self'];
      $ox = $LX + ($others / $gmax) * $CW; $sx = $LX + ($self / $gmax) * $CW;
      $setFill(array(37, 99, 235)); $pdf->Rect($ox - 1, $y - 1.3, 2, 3.8, 'F');
      $setFill(array(234, 88, 12)); $pdf->Rect($sx - 1, $y - 1.3, 2, 3.8, 'F');
      $pdf->SetY($y + 5);
    }
    $pdf->Ln(1); $pdf->SetFont('dv', '', 8); $setText($MUTE);
    $pdf->Cell(0, 4, 'Niebieski: średnia otoczenia. Pomarańczowy: samoocena.', 0, 1);
    if (!empty($d['analitykaLuki'])) { $pdf->Ln(1.5); foreach ($d['analitykaLuki'] as $p) $para($S($p)); }
  }

  // ---------- PERSPEKTYWY: KTO JAK OCENIA (per kompetencja) ----------
  if (!empty($d['perspectives']['items']) && is_array($d['perspectives']['items'])) {
    $pdf->AddPage(); if ($Lpe !== null) $pdf->SetLink($Lpe, -1);
    $h2('Perspektywy: kto jak ocenia');
    $para('Dla każdej wartości widać, jak ocenia ją każda grupa osobno. Pionowa kreska to średnia otoczenia. Gdzie jedna grupa odstaje w dół, to ona ciągnie wynik.');
    $pmax = isset($d['perspectives']['max']) ? (float)$d['perspectives']['max'] : 4.0;
    $valColor = function ($v) {
      if ($v < 1.7) return array(220, 38, 38);
      if ($v < 2.7) return array(234, 88, 12);
      if ($v < 3.7) return array(22, 163, 74);
      return array(37, 99, 235);
    };
    $labW = 34; $valW = 12; $barX = $LX + $labW; $barW = $CW - $labW - $valW;
    foreach ($d['perspectives']['items'] as $it) {
      if ($pdf->GetY() > 230) $pdf->AddPage();
      $pdf->Ln(1.5);
      $pdf->SetFont('dv', 'B', 11); $setText($NAVY);
      $pdf->Cell(120, 7, $S(@$it['name']), 0, 0);
      $pdf->SetFont('dv', '', 9); $setText($MUTE);
      $pdf->Cell($CW - 120, 7, 'Średnia otoczenia: ' . number_format((float)@$it['avg'], 1), 0, 1, 'R');
      $avgX = $barX + ((float)@$it['avg'] / $pmax) * $barW;
      $barsTop = $pdf->GetY();
      foreach (($it['bars'] ?? array()) as $b) {
        $y = $pdf->GetY();
        $pdf->SetFont('dv', '', 9); $setText($INK);
        $pdf->SetXY($LX, $y); $pdf->Cell($labW, 5.5, $S(@$b['label']), 0, 0);
        $setFill(array(238, 240, 243)); $pdf->Rect($barX, $y + 1, $barW, 4, 'F');
        if (isset($b['val']) && $b['val'] !== null) {
          $v = (float)$b['val']; $bc = $valColor($v);
          $setFill($bc); $pdf->Rect($barX, $y + 1, max(0.6, ($v / $pmax) * $barW), 4, 'F');
          $pdf->SetFont('dv', 'B', 9); $setText($bc);
          $pdf->SetXY($barX + $barW + 1, $y); $pdf->Cell($valW - 1, 5.5, number_format($v, 1), 0, 0, 'R');
        } else {
          $pdf->SetFont('dv', '', 8); $setText($MUTE);
          $pdf->SetXY($barX + $barW + 1, $y); $pdf->Cell($valW - 1, 5.5, 'brak', 0, 0, 'R');
        }
        $pdf->SetY($y + 6);
      }
      $barsBottom = $pdf->GetY() - 1;
      $setDraw($NAVY); $pdf->SetLineWidth(0.4); $pdf->Line($avgX, $barsTop + 0.5, $avgX, $barsBottom); $pdf->SetLineWidth(0.2); $setDraw($LINE);
      if (!empty($it['note'])) {
        $pdf->Ln(0.5); $pdf->SetFont('dv', '', 8.5); $setText(array(75, 85, 99));
        $pdf->MultiCell($CW, 4.4, $S($it['note']), 0, 'L');
      }
    }
    if (!empty($d['perspektywySynteza'])) {
      if ($pdf->GetY() > 245) $pdf->AddPage();
      $pdf->Ln(2);
      $y = $pdf->GetY(); $setFill(array(240, 245, 252)); $pdf->Rect($LX, $y, $CW, 1.2, 'F'); $pdf->SetY($y + 3);
      $pdf->SetFont('dv', 'B', 10); $setText($NAVY); $pdf->Cell(0, 6, 'Wzorzec perspektyw', 0, 1);
      $para($S($d['perspektywySynteza']));
    }
  }

  // ---------- KOMPETENCJE ----------
  $bandTint = function ($label) {
    $l = mb_strtolower($label);
    if (strpos($l, 'niedob') !== false) return array(220, 38, 38);
    if (strpos($l, 'poniż') !== false || strpos($l, 'poniz') !== false) return array(234, 88, 12);
    if (strpos($l, 'ponad') !== false) return array(37, 99, 235);
    if (strpos($l, 'optym') !== false) return array(22, 163, 74);
    return array(107, 114, 128);
  };

  if (!empty($d['competencies']) && is_array($d['competencies'])) {
    foreach ($d['competencies'] as $idx => $c) {
      $pdf->AddPage();
      if (isset($compLinks[$idx])) $pdf->SetLink($compLinks[$idx], -1);
      $rgb = (isset($c['rgb']) && is_array($c['rgb'])) ? $c['rgb'] : $NAVY;

      // nagłówek wartości (kolorowy pasek)
      $y = $pdf->GetY();
      $setFill($rgb); $pdf->Rect($LX, $y, $CW, 18, 'F');
      $pdf->SetFont('dv', 'B', 15); $setText(array(255, 255, 255));
      $pdf->SetXY($LX + 5, $y + 2.5); $pdf->Cell(120, 7, $S(@$c['name']), 0, 0);
      $pdf->SetFont('dv', '', 9); $setText(array(255, 255, 255));
      $pdf->SetXY($LX + 5, $y + 10); $pdf->Cell(120, 5, 'Wartość ' . ($idx + 1) . ' z ' . count($d['competencies']) . '   ·   ' . $S(@$c['band']), 0, 0);
      $pdf->SetFont('dv', 'B', 20); $setText(array(255, 255, 255));
      $pdf->SetXY($RX - 45, $y + 4); $pdf->Cell(40, 10, $S(@$c['score']), 0, 0, 'R');
      $pdf->SetY($y + 23);

      // pasek wyniku 0..max ze strefami
      $max = isset($c['scoreMax']) ? (float)$c['scoreMax'] : 4.0;
      $val = isset($c['score']) ? (float)$c['score'] : 0.0;
      $barY = $pdf->GetY(); $barH = 6; $barW = $CW;
      if (!empty($c['zones']) && is_array($c['zones'])) {
        foreach ($c['zones'] as $z) {
          $zf = (float)@$z['from']; $zt = (float)@$z['to']; $zc = (isset($z['rgb']) && is_array($z['rgb'])) ? $z['rgb'] : array(229, 231, 235);
          $zx = $LX + ($zf / $max) * $barW; $zw = (($zt - $zf) / $max) * $barW;
          $setFill($zc); $pdf->Rect($zx, $barY, $zw, $barH, 'F');
        }
      } else { $setFill($LINE); $pdf->Rect($LX, $barY, $barW, $barH, 'F'); }
      // marker wyniku
      $mx = $LX + ($val / $max) * $barW;
      $setFill($NAVY); $pdf->Rect($mx - 0.8, $barY - 1.5, 1.6, $barH + 3, 'F');
      $pdf->SetY($barY + $barH + 2);
      $pdf->SetFont('dv', '', 8); $setText($MUTE);
      $pdf->Cell(0, 4, 'Skala 0-' . rtrim(rtrim(number_format($max, 1), '0'), '.') . '   ·   ' . $S(@$c['gap']), 0, 1);
      $pdf->Ln(2);

      // zachowania
      if (!empty($c['behaviors']) && is_array($c['behaviors'])) {
        $pdf->SetFont('dv', 'B', 9); $setText($NAVY);
        $pdf->Cell(0, 6, 'Zachowania', 0, 1);
        foreach ($c['behaviors'] as $b) {
          if ($pdf->GetY() > 250) $pdf->AddPage();
          $bc = $bandTint($S(@$b['band']));
          $pdf->SetFont('dv', '', 9); $setText($INK);
          $pdf->Cell(135, 5.4, $S(@$b['name']), 0, 0);
          $setText($bc); $pdf->SetFont('dv', 'B', 9);
          $pdf->Cell($CW - 135, 5.4, $S(@$b['score']) . '  ' . $S(@$b['band']), 0, 1, 'R');
        }
        $pdf->Ln(2);
      }

      // rekomendacje
      if (!empty($c['recommendations']) && is_array($c['recommendations'])) {
        $pdf->SetFont('dv', 'B', 9); $setText($NAVY);
        $pdf->Cell(0, 6, 'Rekomendacje', 0, 1);
        foreach ($c['recommendations'] as $r) {
          if ($pdf->GetY() > 245) $pdf->AddPage();
          $y2 = $pdf->GetY();
          $setDraw($LINE); $setFill(array(252, 252, 253));
          // policz wysokość bloku w przybliżeniu
          $pdf->SetFont('dv', 'B', 10); $setText($INK);
          $pdf->SetXY($LX + 4, $y2 + 2.5);
          $pdf->MultiCell($CW - 8, 5.2, $S(@$r['title']), 0, 'L');
          $pdf->SetFont('dv', '', 9); $setText(array(75, 85, 99));
          $pdf->SetX($LX + 4);
          $pdf->MultiCell($CW - 8, 4.8, $S(@$r['action']), 0, 'L');
          if (!empty($r['horizon'])) {
            $pdf->SetFont('dv', 'B', 8); $setText($rgb);
            $pdf->SetX($LX + 4); $pdf->Cell(0, 5, mb_strtoupper($S($r['horizon'])), 0, 1);
          }
          $y3 = $pdf->GetY() + 2;
          $setDraw($LINE); $pdf->Line($LX, $y3, $RX, $y3);
          $pdf->SetY($y3 + 2.5);
        }
      }

      if (!empty($c['note'])) {
        $pdf->Ln(1); $pdf->SetFont('dv', '', 9); $setText($MUTE);
        $pdf->MultiCell($CW, 4.8, $S($c['note']), 0, 'L');
      }
    }
  }

  // ---------- PLAN ----------
  if (!empty($d['plan']) && is_array($d['plan'])) {
    $pdf->AddPage();
    if ($Lp !== null) $pdf->SetLink($Lp, -1);
    $pdf->SetFont('dv', 'B', 14); $setText($NAVY);
    $pdf->Cell(0, 9, $S(@$d['plan']['title'], 'Plan rozwoju'), 0, 1); $pdf->Ln(1);
    if (!empty($d['plan']['priorities'])) {
      $pdf->SetFont('dv', 'B', 10); $setText($INK); $pdf->Cell(0, 6, 'Priorytety', 0, 1);
      foreach ($d['plan']['priorities'] as $i => $p) {
        $pdf->SetFont('dv', '', 10); $setText($INK);
        $pdf->Cell(7, 5.4, ($i + 1) . '.', 0, 0); $pdf->MultiCell($CW - 7, 5.4, $S($p), 0, 'L');
      }
      $pdf->Ln(2);
    }
    if (!empty($d['plan']['questions'])) {
      $pdf->SetFont('dv', 'B', 10); $setText($INK); $pdf->Cell(0, 6, 'Pytania do rozmowy', 0, 1);
      foreach ($d['plan']['questions'] as $q) {
        $pdf->SetFont('dv', '', 10); $setText($INK);
        $pdf->Cell(5, 5.4, '·', 0, 0); $pdf->MultiCell($CW - 5, 5.4, $S($q), 0, 'L');
      }
    }
  }

  // ---------- PYTANIA OTWARTE (cytaty wg grupy oceniającej) ----------
  if (!empty($d['openAnswers']) && is_array($d['openAnswers'])) {
    $pdf->AddPage();
    if ($Lo !== null) $pdf->SetLink($Lo, -1);
    $h2('Pytania otwarte');
    $para('Odpowiedzi własnymi słowami, pogrupowane wg grupy oceniającej. Anonimowo, bez nazwisk.');
    foreach ($d['openAnswers'] as $grp) {
      if ($pdf->GetY() > 250) $pdf->AddPage();
      $pdf->Ln(1);
      $pdf->SetFont('dv', 'B', 11); $setText($NAVY);
      $pdf->Cell(0, 7, $S(@$grp['role']), 0, 1);
      if (!empty($grp['questions']) && is_array($grp['questions'])) {
        foreach ($grp['questions'] as $qq) {
          if ($pdf->GetY() > 255) $pdf->AddPage();
          $pdf->SetFont('dv', 'B', 9.5); $setText($INK);
          $pdf->MultiCell($CW, 5, $S(@$qq['q']), 0, 'L');
          if (!empty($qq['quotes']) && is_array($qq['quotes'])) {
            foreach ($qq['quotes'] as $quote) {
              if ($pdf->GetY() > 258) $pdf->AddPage();
              $pdf->SetFont('dv', '', 9.5); $setText(array(75, 85, 99));
              $pdf->Cell(4, 4.8, '', 0, 0);
              $pdf->MultiCell($CW - 4, 4.8, '„' . $S($quote) . '”', 0, 'L');
            }
          }
          $pdf->Ln(1.5);
        }
      }
    }
  }

  $fname = $S(@$d['filename'], 'Raport-360.pdf');
  $out = $pdf->Output('S');
  if (!headers_sent()) {
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9._-]/', '-', $fname) . '"');
    header('Content-Length: ' . strlen($out));
    header('Cache-Control: no-store');
  }
  echo $out;
}
